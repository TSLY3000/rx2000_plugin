// logger.cpp
#include "logger.h"
#include <chrono>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <sstream>


#define LOG_FILE_PATH "C:/Users/ASPEED_ASUS/Desktop/Nx Plugins/Nx Software Development Kit(SDK)/metadata_sdk/plugins/rx2000/src/nx/vms_server_plugins/analytics/rx2000/log.txt"

// Initiate & Open Logger
Logger::Logger() {
    logFile_.open(LOG_FILE_PATH, std::ios::app);
    if (!logFile_) {
        std::cerr << "Failed to open log file: " << LOG_FILE_PATH << std::endl;
    }
}

// Close Log
Logger::~Logger() {
    if (logFile_.is_open())
        logFile_.close();
}

Logger& Logger::getInstance() {
    static Logger instance;
    return instance;
}

void Logger::log(const std::string& message) {
    std::lock_guard<std::mutex> lock(logMutex_);

    if (!logFile_.is_open())
        return;

    // Current time
    auto now = std::chrono::system_clock::now();
    auto now_c = std::chrono::system_clock::to_time_t(now);
    std::tm now_tm = *std::localtime(&now_c);

    // Format current date
    std::ostringstream currentDateStream;
    currentDateStream << std::put_time(&now_tm, "%F"); // YYYY-MM-DD
    std::string currentDate = currentDateStream.str();

    // Add date separator if needed
    static std::string lastDate = "";
    if (currentDate != lastDate) {
        logFile_ << "\n======== " << currentDate << " ========\n";
        lastDate = currentDate;
    }

    // Prepare timestamp prefix
    std::ostringstream prefixStream;
    prefixStream << "[" << std::put_time(&now_tm, "%F %T") << "] ";
    std::string timestampPrefix = prefixStream.str();

    // Split message into lines
    std::istringstream msgStream(message);
    std::string line;
    bool firstLine = true;

    while (std::getline(msgStream, line)) {
        if (firstLine) {
            logFile_ << timestampPrefix << line << std::endl;
            firstLine = false;
        }
        else {
            // Pad subsequent lines to align with the message
            logFile_ << std::string(timestampPrefix.length(), ' ') << line << std::endl;
        }
    }
}
