// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#include "engine.h"
#include "device_agent.h"

#include <thread>
#include <chrono>
#include <iostream>
#include <nx/vms_server_plugins/analytics/rx2000/logger.h>

namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace rx2000 {
namespace object_detection {

using namespace nx::sdk;
using namespace nx::sdk::analytics;


Engine::Engine() :
    // Call the DeviceAgent helper class constructor telling it to verbosely report to stderr.
    nx::sdk::analytics::Engine(/*enableOutput*/ true)
{

}

Engine::~Engine()
{
}



/**
    * Called when the Server opens a video-connection to the camera if the plugin is enabled for this
    * camera.
    *
    * @param outResult The pointer to the structure which needs to be filled with the resulting value
    *     or the error information.
    * @param deviceInfo Contains various information about the related device such as its id, vendor,
    *     model, etc.
    */
void Engine::doObtainDeviceAgent(Result<IDeviceAgent*>* outResult, const IDeviceInfo* deviceInfo)
{
    *outResult = new DeviceAgent(deviceInfo);
}

/**
    * @return JSON with the particular structure. Note that it is possible to fill in the values
    *     that are not known at compile time, but should not depend on the Engine settings.
    */
std::string Engine::manifestString() const
{
    return 1 + (const char*)R"json(
{
    "id": "rx2000.object.detection",
    "name": "RX2000 Object Detection",
    "description": "Integrates RX2000's AI-powered Object Detection algorithm with Nx Witness. This plugin receives real-time event data from IronYun's backend and overlays intrusion alerts directly on the video stream, enabling accurate, responsive, and efficient perimeter protection within the Nx environment.",
    "version": "1.2.0",
    "vendor": "ASPEED",

    "deviceAgentSettingsModel": {
            "type": "Settings",
            "items":
            [
                {
                    "type": "GroupBox",
                    "caption": "Camera Settings",
                    "items":
                    [
                        {
                            "type": "SpinBox",
                            "name": ")json" + kDetectionIntervalSettings + R"json(",
                            "caption": "Detection Interval(ms)",
                            "defaultValue": 100
                        },
                        {
                            "type": "TextField",
                            "name": ")json" + kCameraIPSettings + R"json(",
                            "caption": "Camera IP Address",
                            "defaultValue": "192.168.70.182"
                        },
                        {
                            "type": "TextField",
                            "name": ")json" + kPortSettings + R"json(",
                            "caption": "Port",
                            "defaultValue": "80"
                        }   ,
                        {
                            "type": "CheckBox",
                            "caption": "Start requesting data?",
                            "name": "startReq",
                            "defaultValue": false
                        }

                    ]
                }
            ]
        } 
}
)json";
}




} // namespace object_detection
} // namespace rx2000
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
