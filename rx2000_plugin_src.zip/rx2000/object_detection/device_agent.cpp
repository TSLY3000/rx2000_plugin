// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#include "device_agent.h"
#include "../logger.h"
#include "device_agent_manifest.h"
#include "json.hpp"
#include <iostream>
#include <sstream>
#include <thread>
#include <chrono>
#include <cpr/cpr.h>
#include <curl/curl.h>
#include <thread>

#include <nx/kit/json.h>
#include <nx/sdk/analytics/helpers/event_metadata.h>
#include <nx/sdk/analytics/helpers/event_metadata_packet.h>
#include <nx/sdk/analytics/helpers/object_metadata.h>
#include <nx/sdk/analytics/helpers/object_metadata_packet.h>

#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/beast/version.hpp>
#include <boost/asio/connect.hpp>
#include <boost/asio/ip/tcp.hpp>

#define NX_DEBUG_ENABLE_OUTPUT true
#include <nx/kit/debug.h>

#include <sstream>
#include <cstdlib>
#include <string>
#include <iostream>

namespace beast = boost::beast;
namespace http = beast::http;
namespace net = boost::asio;
using tcp = net::ip::tcp;



namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace rx2000 {
namespace object_detection {

using namespace nx::sdk;
using namespace nx::sdk::analytics;
using json = nlohmann::json;


    /**
        * @param deviceInfo Various information about the related device, such as its id, vendor, model,
        *     etc.
        */
    DeviceAgent::DeviceAgent(const nx::sdk::IDeviceInfo* deviceInfo) :
        // Call the DeviceAgent helper class constructor telling it to verbosely report to stderr.
        ConsumingDeviceAgent(deviceInfo, /*enableOutput*/ true)
    {
    }

    DeviceAgent::~DeviceAgent()
    {
        m_stopWorker = true;
        if (m_workerThread.joinable())
            m_workerThread.join();
    }


    std::string reqCamData(std::string camIP, std::string camPort)
    {
        try
        {
            // Set up I/O context
            net::io_context ioc;

            // Resolve localhost:3441
            tcp::resolver resolver(ioc);
            auto const results = resolver.resolve(camIP, camPort);
			std::string camFullAddy = camIP + ":" + camPort;

            // Open TCP connection
            tcp::socket socket(ioc);
            net::connect(socket, results.begin(), results.end());
			Logger::getInstance().log("[INFO] Connected to camera at: " + camFullAddy);

            // Prepare the JSON body
            const std::string jsonPayload = R"({"name":"camera.getOptions","parameters":{"optionNames":["_aiResult"]}})";


			Logger::getInstance().log("[INFO] Sending request to camera: " + jsonPayload);
            // Create HTTP POST request
            http::request<http::string_body> req{ http::verb::post, "/osc/commands/execute", 11 };
            if (camPort == "80")
                req.set(http::field::host, camIP);
            else
                req.set(http::field::host, camFullAddy);
            req.set(http::field::user_agent, BOOST_BEAST_VERSION_STRING);
            req.set(http::field::content_type, "application/json");
            req.body() = jsonPayload;
            req.prepare_payload();  // sets Content-Length

            // Send the request
            http::write(socket, req);

            // Buffer + response container
            beast::flat_buffer buffer;
            http::response<http::string_body> res;

            // Read response
            http::read(socket, buffer, res);

            Logger::getInstance().log("[INFO] Response Code: " + std::to_string(res.result_int()));
            Logger::getInstance().log("[INFO] Response Body: " + res.body());

          
            // Check if body is valid JSON
            try {
                json::parse(res.body());  // just checking if it's valid
            }
            catch (const std::exception& e) {
                Logger::getInstance().log("[ERROR] Invalid JSON in response: " + std::string(e.what()));

                return R"({
                            "results": {
                                "options": {
                                    "_aiResult": {
                                        "result": []
                                    }
                                }
                            }
                        })";  // Return fallback JSON string
            }



            // Gracefully close the socket
            beast::error_code ec;
            socket.shutdown(tcp::socket::shutdown_both, ec);
            if (ec && ec != beast::errc::not_connected)
                throw beast::system_error{ ec };

            return res.body();
        }
        catch (const std::exception& e)
        {
            Logger::getInstance().log("[ERROR] Boost.Beast exception: " + std::string(e.what()));
            return "{}"; 
        }

        
    }

    uint64_t getCurrentTimeMillis()
    {
        using namespace std::chrono;

        return duration_cast<milliseconds>(
            system_clock::now().time_since_epoch()
        ).count();
    }

    void DeviceAgent::reqAndParse(std::string camIP, std::string camPort, int interval)
    {
        m_workerThread = std::thread([this, camIP, camPort, interval]()
            {
                while (!m_stopWorker)
                {
					Logger::getInstance().log("[OBJECT DETECTION][ENGINE] Requesting camera data...");
                    std::string camData = reqCamData(camIP, camPort);
                 
                    json camDataParsed = json::parse(camData);
                    
                    Logger::getInstance().log("[INFO] Camera Data: " + camData);


                    const auto& objectsData = camDataParsed["results"]["options"]["_aiResult"]["result"];
                    std::vector<std::tuple<std::string, float, float, float, float, float>> objects;


                    // Include ROI shifts as well
                    const auto& roiData = camDataParsed["results"]["options"]["_aiResult"]["roiInfo"];
					
					float total_width = roiData.value("eqtWidth", 3840.0f);
					float total_height = roiData.value("eqtHeight", 1920.0f);

                    for (const auto& obj : objectsData) {
                        std::string objectType = obj.value("class", "");
                        float x1 = obj.value("x1", -1.0f) ;
                        float x2 = obj.value("x2", -1.0f) ;
                        float y1 = obj.value("y1", -1.0f) ;
                        float y2 = obj.value("y2", -1.0f) ;

                        float x = x1 / total_width;
                        float y = y1 / total_height;
                        float w = (x2 - x1) / total_width;
                        float h = (y2 - y1) / total_height;
                        float confidence = obj.value("confidenceLevel", 0.0f);
                        objects.emplace_back(objectType, x, y, w, h, confidence);
                    }

                    int64_t datetime_ms = getCurrentTimeMillis();
                    int64_t datetime_Us = datetime_ms*1000;

                    auto objectMetadataPacket = DeviceAgent::generateObjectMetadataPacket(objects, datetime_Us);
                    pushMetadataPacket(objectMetadataPacket.releasePtr());
                    Logger::getInstance().log("[OBJECT DETECTION][ENGINE] Object created and pushed.");
                    Logger::getInstance().log("[OBJECT DETECTION][ENGINE] JSON request fully parsed.");

                    for (int i = 0; i < interval && !m_stopWorker; ++i)
                        std::this_thread::sleep_for(std::chrono::milliseconds(1));
                }
            });
    }


    /**
        *  @return JSON with the particular structure. Note that it is possible to fill in the values
        * that are not known at compile time, but should not depend on the DeviceAgent settings.
        */
    std::string DeviceAgent::manifestString() const
    {
        return kDeviceAgentManifest;
    }



    Result<const ISettingsResponse*> DeviceAgent::settingsReceived()
    {
        std::map<std::string, std::string> settings = currentSettings();
		Logger::getInstance().log("[INFO] DeviceAgent settings received.");

		// Stop the worker thread if it is running
        m_stopWorker = true;
        if (m_workerThread.joinable())
            m_workerThread.join();


        std::string start = settings[kStartGettingData];
		Logger::getInstance().log("[INFO] Start getting data setting: " + start);

        
        

        // Get port values from settings and changing it to int
        interval = std::stoi(settings[kDetectionIntervalSettings]);
        // cameraIP = settings[kCameraIPSettings];
		cameraIP = "192.168.70.101";  // Hardcoded for testing
		cameraPort = settings[kPortSettings];  

        m_stopWorker = false;
        if (start == "true")
        {
            Logger::getInstance().log("[OBJECT DETECTION][ENGINE] Starting worker thread to request camera data.");
            reqAndParse(cameraIP, cameraPort, interval);
        }
        else
        {
            Logger::getInstance().log("[OBJECT DETECTION][ENGINE] Not starting worker thread, settings indicate not to.");
		}
        
        return nullptr;
    }
    

    /**
        * Called when the Server sends a new compressed frame from a camera.
        */
    bool DeviceAgent::pushCompressedVideoFrame(const ICompressedVideoPacket* videoFrame)
    {
        if (!videoFrame)
        {
            Logger::getInstance().log("[OBJECT DETECTION][Error] Received null video frame.");
            return false;
        }

        if (videoFrame->width() == 0 || videoFrame->height() == 0)
        {
            Logger::getInstance().log("[OBJECT DETECTION][Error] Received frame with invalid dimensions.");
            return false;
        }

        ++m_frameIndex;
        int64_t m_lastVideoFrameTimestampUs = videoFrame->timestampUs();
        int m_frameWidth = videoFrame->width();
        int m_frameHeight = videoFrame->height();

        return true; //< There were no errors while processing the video frame.
    }

    /**
        * Serves the similar purpose as pushMetadataPacket(). The differences are:
        * - pushMetadataPacket() is called by the plugin, while pullMetadataPackets() is called by Server.
        * - pushMetadataPacket() expects one metadata packet, while pullMetadataPacket expects the
        *     std::vector of them.
        *
        * There are no strict rules for deciding which method is "better". A rule of thumb is to use
        * pushMetadataPacket() when you generate one metadata packet and do not want to store it in the
        * class field, and use pullMetadataPackets otherwise.
        */
    bool DeviceAgent::pullMetadataPackets(std::vector<IMetadataPacket*>* metadataPackets)
    {
        // metadataPackets->push_back(generateObjectMetadataPacket(normX, normY, normW, normH).releasePtr());

        return true; //< There were no errors while filling metadataPackets.
    }


    void DeviceAgent::doSetNeededMetadataTypes(
        nx::sdk::Result<void>* /*outValue*/,
        const nx::sdk::analytics::IMetadataTypes* /*neededMetadataTypes*/)
    {
    }


    static void addAttributesFromProperty(const nlohmann::json& property, nx::sdk::Ptr<nx::sdk::analytics::ObjectMetadata> objectMetadata)
    {
        for (auto it = property.begin(); it != property.end(); ++it)
        {
            const std::string& key = it.key();
            const auto& value = it.value();

            if (value.is_string())
            {
                objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, value.get<std::string>()));
            }
            else if (value.is_number())
            {
                objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, std::to_string(value.get<double>())));
            }
            else if (value.is_boolean())
            {
                objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, value.get<bool>() ? "true" : "false"));
            }
            else if (value.is_array())
            {
                for (const auto& item : value)
                {
                    if (item.is_string())
                        objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, item.get<std::string>()));
                    else if (item.is_number())
                        objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, std::to_string(item.get<double>())));
                    else if (item.is_boolean())
                        objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, item.get<bool>() ? "true" : "false"));
                }
            }
        }
    }



    Ptr<IMetadataPacket> DeviceAgent::generateObjectMetadataPacket(const std::vector<std::tuple<std::string, float, float, float, float, float>>& objects, int64_t timestamp)
    {
        auto packet = makePtr<ObjectMetadataPacket>();
        int64_t timestampUs = timestamp;
        packet->setTimestampUs(timestampUs);
        packet->setDurationUs(2000000);

        for (const auto& [objectType, x, y, w, h, confidence] : objects) {
        auto objectMetadata = makePtr<ObjectMetadata>();

        float norm_x = x;
        float norm_y = y;
        float norm_w = w;
        float norm_h = h;

        // Logger::getInstance().log(std::to_string(frameWidth));
        // Logger::getInstance().log(std::to_string(frameHeight));

        // float streamFrameWidth = frameWidth;
        // float streamFrameHeight = frameHeight;

        if (x > 1 || y > 1 || w > 1 || h > 1)
        {
            norm_x = x / 3840;
            norm_y = y / 1920;
            norm_w = w / 3840;
            norm_h = h / 1920;
        }
        Logger::getInstance().log(
            "[OBJECT DETECTION][Object] Type: " + objectType +
            ", x: " + std::to_string(norm_x) +
            ", y: " + std::to_string(norm_y) +
            ", w: " + std::to_string(norm_w) +
            ", h: " + std::to_string(norm_h) +
            ", confidence: " + std::to_string(confidence));


        // Change Object Type to corresponding ID
        objectMetadata->setTypeId("ironyun.person.object");
        nx::sdk::Uuid m_trackId = nx::sdk::UuidHelper::randomUuid();
        objectMetadata->setTrackId(m_trackId);
        objectMetadata->setBoundingBox(Rect(norm_x, norm_y, norm_w, norm_h));
        objectMetadata->setConfidence(confidence);

        packet->addItem(objectMetadata.get());
    }

    return packet;
    }


    void DeviceAgent::publishPacket(nx::sdk::analytics::IMetadataPacket* packet)
    {
        pushMetadataPacket(packet);

    }



    //-------------------------------------------------------------------------------------------------
    // private

    Ptr<IMetadataPacket> DeviceAgent::generateEventMetadataPacket()
    {
        // EventMetadataPacket contains arbitrary number of EventMetadata.
        const auto eventMetadataPacket = makePtr<EventMetadataPacket>();
        eventMetadataPacket->setTimestampUs(m_lastVideoFrameTimestampUs);
        eventMetadataPacket->setDurationUs(100000);

        const auto eventMetadata = makePtr<EventMetadata>();
        eventMetadata->setTypeId("ironyun.stub.event");
        eventMetadata->setIsActive(true);
        eventMetadata->setCaption("Intrusion Detected");
        eventMetadata->setDescription("New track #" + std::to_string(m_trackIndex) + " started");

        eventMetadataPacket->addItem(eventMetadata.get());

        // Generate index and track id for the next track.
        ++m_trackIndex;
        m_trackId = nx::sdk::UuidHelper::randomUuid();

        return eventMetadataPacket;
    }

} // namespace object_detection
} // namespace rx2000
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
