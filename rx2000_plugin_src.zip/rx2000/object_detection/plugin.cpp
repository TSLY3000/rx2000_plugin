// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#include "plugin.h"
#include "engine.h"
#include <iostream>
#include "../logger.h"

namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace rx2000 {
namespace object_detection {


using namespace nx::sdk;
using namespace nx::sdk::analytics;

Result<IEngine*> Plugin::doObtainEngine()
{
    return new Engine();
}

    /**
        * JSON with the particular structure. Note that it is possible to fill in the values that are not
        * known at compile time.
        *
        * - id: Unique identifier for a plugin with format "{vendor_id}.{plugin_id}", where
        *     {vendor_id} is the unique identifier of the plugin creator (person or company name) and
        *     {plugin_id} is the unique (for a specific vendor) identifier of the plugin.
        * - name: A human-readable short name of the plugin (displayed in the "Camera Settings" window
        *     of the Client).
        * - description: Description of the plugin in a few sentences.
        * - version: Version of the plugin.
        * - vendor: Plugin creator (person or company) name.
        */
std::string Plugin::manifestString() const
{
    return /*suppress newline*/ 1 + (const char*)R"json(
    {
    "id": "rx2000.object.detection",
    "name": "RX2000 Object Detection",
    "description": "Integrates RX2000's AI-powered Object Detection algorithm with Nx Witness. This plugin receives real-time event data from IronYun's backend and overlays intrusion alerts directly on the video stream, enabling accurate, responsive, and efficient perimeter protection within the Nx environment.",
    "version": "1.2.0",
    "vendor": "ASPEED"    
    }
    )json";
}



} // namespace object_detection
} // namespace rx2000
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
